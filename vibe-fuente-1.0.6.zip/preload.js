const { contextBridge, ipcRenderer } = require('electron');

// Puente seguro entre la web (panel/widgets) y el proceso principal de Electron.
contextBridge.exposeInMainWorld('vibe', {
  // Abrir un widget en el escritorio desde el panel (doble clic en un estilo)
  openWidget: (key) => ipcRenderer.send('vibe-open-widget', key),
  // Cambiar el tamaño del widget actual (factor relativo: >1 agranda, <1 reduce)
  resizeWidget: (factor) => ipcRenderer.send('vibe-resize-widget', factor),
  // Informar de la proporción natural del widget para que la ventana no recorte
  reportAspect: (ratio) => ipcRenderer.send('vibe-aspect', ratio),
  // Controlar la reproducción con las teclas multimedia (funciona en Spotify gratis)
  media: (action) => ipcRenderer.send('vibe-media', action),
  // Cerrar la ventana actual
  closeSelf: () => ipcRenderer.send('vibe-close-self'),
  // Minimizar la ventana actual (va a la barra de tareas, como una ventana normal)
  minimizeSelf: () => ipcRenderer.send('vibe-minimize-self'),
  // Actualizaciones
  checkUpdate: () => ipcRenderer.send('vibe-check-update'),
  restartToUpdate: () => ipcRenderer.send('vibe-restart-update'),
  onUpdateStatus: (cb) => ipcRenderer.on('vibe-update-status', (e, data) => cb(data)),
  // Saber que estamos dentro de la app de escritorio
  isDesktop: true
});
