const { app, BrowserWindow, Tray, Menu, nativeImage, globalShortcut, screen, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
let autoUpdater = null;
try { autoUpdater = require('electron-updater').autoUpdater; } catch (e) {}

// Compositor por software: hace que las ventanas transparentes se dibujen bien en Windows.
app.disableHardwareAcceleration();

const APP_URL = 'https://vibe-app-26r.pages.dev/';
const stateFile = path.join(app.getPath('userData'), 'windows.json');

// Definición de cada widget individual
const WIDGETS = {
  card:   { label: 'Tarjeta', w: 392, h: 470 },
  bar:    { label: 'Barra',   w: 470, h: 110 },
  vinyl:  { label: 'Vinilo',  w: 392, h: 460 },
  poster: { label: 'Póster',  w: 452, h: 600 },
  lyrics: { label: 'Letra',   w: 430, h: 360 }
};
// Estilos visuales (la Letra va aparte y puede coexistir con uno de estos)
const VISUAL = ['card', 'bar', 'vinyl', 'poster'];

let control = null;              // ventana del panel de control
const widgetWins = {};           // ventanas-widget abiertas, por clave
let tray = null;

// ---------- estado (posiciones) ----------
function loadState() { try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch (e) { return {}; } }
let allState = loadState();
function saveState() { try { fs.writeFileSync(stateFile, JSON.stringify(allState)); } catch (e) {} }
function onScreenPos(s) {
  if (!s || typeof s.x !== 'number' || typeof s.y !== 'number') return null;
  const w = s.w || 360, h = s.h || 400;
  const ok = screen.getAllDisplays().some(d => {
    const a = d.workArea;
    return (s.x + w > a.x + 30) && (s.x < a.x + a.width - 30) && (s.y + 20 > a.y) && (s.y < a.y + a.height - 30);
  });
  return ok ? { x: s.x, y: s.y } : null;
}

// ---------- ventana de control (panel completo) ----------
function createControl() {
  const st = allState.control || {};
  const pos = onScreenPos({ ...st, w: st.w || 400, h: st.h || 700 });
  control = new BrowserWindow({
    width: st.w || 400, height: st.h || 700,
    x: pos ? pos.x : undefined, y: pos ? pos.y : undefined, center: !pos,
    minWidth: 320, minHeight: 440,
    frame: false, transparent: false, backgroundColor: '#0a0a0f',
    resizable: true, skipTaskbar: false, show: false, title: 'Vibe — Panel',
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { contextIsolation: true, backgroundThrottling: false, preload: path.join(__dirname, 'preload.js') }
  });
  control.loadURL(APP_URL);
  control.once('ready-to-show', () => {
    control.show(); control.focus();
    // La primera vez que se abre, a pantalla completa (maximizada).
    if (!allState.controlMaximizedOnce) { control.maximize(); allState.controlMaximizedOnce = true; saveState(); }
  });
  setTimeout(() => { if (control && !control.isVisible()) control.show(); }, 2500);
  control.webContents.on('did-finish-load', () => {
    control.webContents.insertCSS('header{-webkit-app-region:no-drag !important;}').catch(() => {});
  });
  control.webContents.setWindowOpenHandler(({ url }) => { control.loadURL(url); return { action: 'deny' }; });
  const rec = () => { if (!control) return; const b = control.getBounds(); allState.control = { x: b.x, y: b.y, w: b.width, h: b.height }; saveState(); };
  control.on('moved', rec); control.on('resize', rec); control.on('close', rec);
  control.on('closed', () => { control = null; });
}
function toggleControl() {
  if (!control) { createControl(); return; }
  if (control.isVisible()) control.hide(); else { control.show(); control.focus(); }
}

// ---------- ventanas-widget individuales ----------
function createWidget(key) {
  const cfg = WIDGETS[key];
  const st = allState['w_' + key] || {};
  const pos = onScreenPos({ ...st, w: cfg.w, h: cfg.h });
  const wwin = new BrowserWindow({
    width: st.w || cfg.w, height: st.h || cfg.h,
    x: pos ? pos.x : undefined, y: pos ? pos.y : undefined, center: !pos,
    minWidth: 160, minHeight: 70,
    frame: false, transparent: true, backgroundColor: '#00000000',
    resizable: true, skipTaskbar: false, hasShadow: false, show: false,
    alwaysOnTop: false, fullscreenable: false, title: 'Vibe ' + cfg.label,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { contextIsolation: true, backgroundThrottling: false, preload: path.join(__dirname, 'preload.js') }
  });
  wwin.loadURL(APP_URL + '?widget=' + key);
  // Mantener la proporción al redimensionar para que no se recorte ni deje huecos.
  try { if (cfg.w && cfg.h) wwin.setAspectRatio(cfg.w / cfg.h); } catch (e) {}
  wwin.once('ready-to-show', () => { wwin.show(); });
  setTimeout(() => { if (widgetWins[key] && !widgetWins[key].isVisible()) widgetWins[key].show(); }, 2500);
  wwin.webContents.setWindowOpenHandler(({ url }) => { wwin.loadURL(url); return { action: 'deny' }; });

  // Menú al clic derecho: siempre encima, tamaño y cerrar.
  function sizeTo(factor) {
    const b = wwin.getBounds();
    wwin.setBounds({ x: b.x, y: b.y, width: Math.round(cfg.w * factor), height: Math.round(cfg.h * factor) });
  }
  wwin.webContents.on('context-menu', () => {
    Menu.buildFromTemplate([
      { label: 'Siempre encima', type: 'checkbox', checked: wwin.isAlwaysOnTop(),
        click: (it) => wwin.setAlwaysOnTop(it.checked, 'floating') },
      { label: 'Tamaño', submenu: [
        { label: 'Pequeño', click: () => sizeTo(0.75) },
        { label: 'Mediano', click: () => sizeTo(1) },
        { label: 'Grande', click: () => sizeTo(1.4) },
        { label: 'Enorme', click: () => sizeTo(1.9) }
      ] },
      { label: 'Centrar en pantalla', click: () => wwin.center() },
      { label: 'Minimizar', click: () => wwin.minimize() },
      { type: 'separator' },
      { label: 'Cerrar este widget', click: () => wwin.close() }
    ]).popup({ window: wwin });
  });
  const rec = () => { if (!widgetWins[key]) return; const b = wwin.getBounds(); allState['w_' + key] = { x: b.x, y: b.y, w: b.width, h: b.height }; saveState(); };
  wwin.on('moved', rec); wwin.on('resize', rec); wwin.on('close', rec);
  // Actualizar la bandeja cuando se minimiza/recupera, para que el check refleje si está en pantalla.
  wwin.on('minimize', buildTray); wwin.on('restore', buildTray); wwin.on('show', buildTray); wwin.on('hide', buildTray);
  wwin.on('closed', () => { delete widgetWins[key]; buildTray(); });
  widgetWins[key] = wwin;
}
function toggleWidget(key) {
  const w = widgetWins[key];
  if (w) {
    // Si está minimizado u oculto, RECUPERARLO (no cerrarlo).
    if (w.isMinimized()) { w.restore(); w.show(); w.focus(); return; }
    if (!w.isVisible()) { w.show(); w.focus(); return; }
    w.close(); return;
  }
  // Un solo estilo visual a la vez (salvo la Letra, y salvo modo múltiple activado)
  if (!allState.multiMode && VISUAL.includes(key)) {
    VISUAL.forEach(k => { if (k !== key && widgetWins[k]) widgetWins[k].close(); });
  }
  createWidget(key);
  buildTray();
}
// Abrir (no alternar): si ya está, lo trae al frente; si no, lo crea.
function openWidget(key) {
  if (!WIDGETS[key]) return;
  if (widgetWins[key]) { try { widgetWins[key].show(); widgetWins[key].focus(); } catch (e) {} return; }
  if (!allState.multiMode && VISUAL.includes(key)) {
    VISUAL.forEach(k => { if (k !== key && widgetWins[k]) widgetWins[k].close(); });
  }
  createWidget(key);
  buildTray();
}

// ---------- teclas multimedia (controla Spotify también en cuentas gratis) ----------
function sendMediaKey(vk) {
  // En Windows: simula la tecla multimedia del teclado mediante keybd_event.
  if (process.platform !== 'win32') return;
  const ps = "Add-Type -Name VibeK -Namespace VibeNs -MemberDefinition '[DllImport(\"user32.dll\")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, System.UIntPtr dwExtraInfo);';" +
    "[VibeNs.VibeK]::keybd_event(" + vk + ",0,0,[System.UIntPtr]::Zero);" +
    "[VibeNs.VibeK]::keybd_event(" + vk + ",0,2,[System.UIntPtr]::Zero);";
  try {
    spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', ps], { windowsHide: true });
  } catch (e) {}
}
const MEDIA_VK = { playpause: 0xB3, next: 0xB0, prev: 0xB1 };

// ---------- comunicación con la web (panel y widgets) ----------
function setupIPC() {
  ipcMain.on('vibe-open-widget', (e, key) => openWidget(key));
  ipcMain.on('vibe-close-self', (e) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.close(); });
  ipcMain.on('vibe-minimize-self', (e) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.minimize(); });
  ipcMain.on('vibe-media', (e, action) => { if (MEDIA_VK[action] != null) sendMediaKey(MEDIA_VK[action]); });
  ipcMain.on('vibe-resize-widget', (e, factor) => {
    const w = BrowserWindow.fromWebContents(e.sender); if (!w) return;
    const b = w.getBounds();
    let nw = Math.round(b.width * factor);
    nw = Math.max(150, Math.min(1100, nw));
    const ratio = b.width / b.height;
    const nh = Math.round(nw / ratio);
    w.setBounds({ x: b.x, y: b.y, width: nw, height: nh });
  });
  ipcMain.on('vibe-aspect', (e, ratio) => {
    const w = BrowserWindow.fromWebContents(e.sender); if (!w || !ratio || ratio <= 0) return;
    try { w.setAspectRatio(ratio); } catch (err) {}
    // Ajusta la altura a la proporción real manteniendo el ancho actual.
    const b = w.getBounds();
    const nh = Math.round(b.width / ratio);
    if (Math.abs(nh - b.height) > 2) w.setBounds({ x: b.x, y: b.y, width: b.width, height: nh });
  });
  // Actualizaciones manuales desde el panel
  ipcMain.on('vibe-check-update', () => {
    if (!autoUpdater) { sendUpdateStatus({ state: 'unsupported' }); return; }
    sendUpdateStatus({ state: 'checking' });
    autoUpdater.checkForUpdates().catch(() => sendUpdateStatus({ state: 'error' }));
  });
  ipcMain.on('vibe-restart-update', () => {
    if (!autoUpdater) return;
    app.isQuitting = true;
    sendUpdateStatus({ state: 'installing' });
    // Cerrar TODO para que el instalador pueda reemplazar los archivos (si no, la app sigue viva en la bandeja y la actualización no se aplica).
    try { if (tray) { tray.destroy(); tray = null; } } catch (e) {}
    try {
      BrowserWindow.getAllWindows().forEach(w => {
        try { w.removeAllListeners('close'); } catch (e) {}
        try { w.destroy(); } catch (e) {}
      });
    } catch (e) {}
    // isSilent=true (sin UI), isForceRunAfter=true (reabrir ya actualizada)
    setImmediate(() => { try { autoUpdater.quitAndInstall(true, true); } catch (e) { try { app.quit(); } catch (e2) {} } });
  });
}
function sendUpdateStatus(data) { try { if (control && !control.isDestroyed()) control.webContents.send('vibe-update-status', data); } catch (e) {} }

// ---------- bandeja ----------
function trayIcon() {
  const img = nativeImage.createFromPath(path.join(__dirname, 'icon.png'));
  return img.isEmpty() ? nativeImage.createEmpty() : img.resize({ width: 16, height: 16 });
}
function buildTray() {
  if (!tray) { tray = new Tray(trayIcon()); tray.setToolTip('Vibe — Widgets de Spotify'); tray.on('double-click', toggleControl); }
  const widgetItems = Object.keys(WIDGETS).map(key => ({
    label: WIDGETS[key].label, type: 'checkbox',
    checked: !!(widgetWins[key] && widgetWins[key].isVisible() && !widgetWins[key].isMinimized()),
    click: () => toggleWidget(key)
  }));
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Ajustes (panel de control)', click: toggleControl },
    { type: 'separator' },
    { label: 'Widgets en el escritorio:', enabled: false },
    ...widgetItems,
    { type: 'separator' },
    { label: 'Permitir varios estilos a la vez', type: 'checkbox', checked: !!allState.multiMode,
      click: (it) => {
        allState.multiMode = it.checked; saveState();
        // Al desactivarlo, si hay varios estilos visuales abiertos, deja solo el primero.
        if (!allState.multiMode) {
          const openVisuals = VISUAL.filter(k => widgetWins[k]);
          openVisuals.slice(1).forEach(k => widgetWins[k].close());
        }
        buildTray();
      } },
    { type: 'separator' },
    { label: 'Salir de Vibe', click: () => { app.isQuitting = true; app.quit(); } }
  ]));
}

// ---------- arranque ----------
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); }
else {
  app.on('second-instance', () => { toggleControl(); });
  app.whenReady().then(() => {
    setupIPC();
    createControl();
    buildTray();
    // Reabrir los widgets que estaban abiertos la última vez.
    (allState.openWidgets || []).forEach(key => { if (WIDGETS[key]) createWidget(key); });
    buildTray();
    globalShortcut.register('Control+Alt+V', toggleControl);
    // Auto-actualización: busca versiones nuevas al abrir y cada hora.
    if (autoUpdater) {
      autoUpdater.autoDownload = true;
      autoUpdater.autoInstallOnAppQuit = true; // al salir de la app (bandeja → Salir) también se instala
      autoUpdater.on('checking-for-update', () => sendUpdateStatus({ state: 'checking' }));
      autoUpdater.on('update-available', (info) => sendUpdateStatus({ state: 'downloading', version: info && info.version }));
      autoUpdater.on('update-not-available', () => sendUpdateStatus({ state: 'uptodate' }));
      autoUpdater.on('download-progress', (p) => sendUpdateStatus({ state: 'downloading', percent: Math.round(p.percent || 0) }));
      autoUpdater.on('update-downloaded', (info) => sendUpdateStatus({ state: 'ready', version: info && info.version }));
      autoUpdater.on('error', () => sendUpdateStatus({ state: 'error' }));
      autoUpdater.checkForUpdatesAndNotify().catch(() => {});
      setInterval(() => { autoUpdater.checkForUpdatesAndNotify().catch(() => {}); }, 60 * 60 * 1000);
    }
  });
  app.on('before-quit', () => { allState.openWidgets = Object.keys(widgetWins); saveState(); });
  app.on('window-all-closed', () => { /* sigue en la bandeja */ });
  app.on('will-quit', () => { globalShortcut.unregisterAll(); });
}
